from typing import Text
from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    params = {'name':'chinmay','place':'Guwahati'}
    return render(request,'index.html',params)

def analyze(request):
    #Get the text
    finaltext = request.POST.get('text','default')
    
    #Get the checkbox value
    removepunc = request.POST.get('removepunc','off')
    uppercase = request.POST.get('uppercase','off')
    newlineremover = request.POST.get('newlineremover', 'off')
    extraspace = request.POST.get('extraspace', 'off')
    countchar = request.POST.get('countchar', 'off')
    
    #check which checkbox is on
    if removepunc == "on":
        punc = '''!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~'''
        analyzeText = ""
        for char in finaltext:
            if char not in punc:
                analyzeText = analyzeText + char
                
        params = {'purpose': "Remove punctuation",'analyzed_text':analyzeText}
        finaltext = analyzeText
        # return render(request,'analyzed.html',params)
    
    if(uppercase == "on"):
        analyzeText = ""
        for char in finaltext:
            analyzeText = analyzeText + char.upper()
        
        params = {'purpose': "UPPERCASE",'analyzed_text':analyzeText}
        # return render(request,'analyzed.html',params)
        finaltext = analyzeText
    
    if(newlineremover == "on"):
        analyzeText = ""
        for char in finaltext:
            if char !="\n" and char != "\r":
                    analyzeText = analyzeText + char

        params = {'purpose': "new line remove", 'analyzed_text': analyzeText}
        # return render(request, 'analyzed.html', params)
        finaltext = analyzeText
    
    if(extraspace == "on"):
        analyzeText = ""
        for index, char in enumerate(finaltext):
            # print(index)
            if not (finaltext[index] == " " and finaltext[index+1] == " "):
                analyzeText = analyzeText + char

        params = {'purpose': "extraspace remove", 'analyzed_text': analyzeText}
        # return render(request, 'analyzed.html', params)
        finaltext = analyzeText
        
    if (countchar == "on"):
        count = 0
        for char in finaltext:
            if char != " " and char != "\n":
                count = count+1
        params = {'purpose': "Total character", 'analyzed_text': finaltext,'count':count}
    
    if(countchar != "on" and extraspace != "on" and newlineremover != "on" and uppercase != "on" and removepunc != "on"):
        return HttpResponse("Error 404!")
        
    return render(request, 'analyzed.html', params)

# def about(request):
#     return HttpResponse("Hello from about")


# def capfirst(request):
#     return HttpResponse("Captilize first")

# def newlineremove(request):
#     return HttpResponse("New line remove")
